// import { Component } from '@angular/core';
// import { RouterOutlet } from '@angular/router';
// import { FooterComponent } from "./footer/footer.component";
// import { HeroComponent } from "./hero/hero.component";
// import { HeaderComponent } from "./header/header.component";
// import { EventListComponent } from "./event-list/event-list.component";

// @Component({
//   selector: 'app-root',
//   standalone: true,
//   imports: [RouterOutlet, FooterComponent, HeroComponent, HeaderComponent, EventListComponent ],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'event-management-platform';
// }

import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    // No imports for EventListComponent here
}
