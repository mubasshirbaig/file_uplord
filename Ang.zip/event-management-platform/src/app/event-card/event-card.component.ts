// import { Component, Input } from '@angular/core';

// @Component({
//     selector: 'app-event-card',
//     templateUrl: './event-card.component.html',
//     styleUrls: ['./event-card.component.css']
// })
// export class EventCardComponent {
//     @Input() event: any; // Replace 'any' with your event type
// }

// import { Component, Input } from '@angular/core';

// @Component({
//     selector: 'app-event-card',
//     templateUrl: './event-card.component.html',
//     styleUrls: ['./event-card.component.css']
// })
// export class EventCardComponent {
//     @Input() event: any; // Define the input property for event data
// }

import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-event-card',
    templateUrl: './event-card.component.html',
    styleUrls: ['./event-card.component.css']
})
export class EventCardComponent {
    @Input() event: any; // Make sure this is defined
}
