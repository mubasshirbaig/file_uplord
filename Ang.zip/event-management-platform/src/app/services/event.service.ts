import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  getEvents() {
    return [
      {
        image: 'path/to/image1.jpg',
        title: 'Event 1',
        date: '2023-10-01',
        location: 'Location 1'
      },
      {
        image: 'path/to/image2.jpg',
        title: 'Event 2',
        date: '2023-10-02',
        location: 'Location 2'
      },
      // Add more events as needed
    ];
  }
}
