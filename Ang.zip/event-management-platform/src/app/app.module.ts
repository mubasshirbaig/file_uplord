// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { RouterModule } from '@angular/router'; // Import RouterModule
// import { AppComponent } from './app.component';
// import { RouterOutlet } from '@angular/router'; // Import RouterOutlet
// import { FooterComponent } from './footer/footer.component'; // Adjust path as needed
// import { HeroComponent } from './hero/hero.component'; // Adjust path as needed
// import { HeaderComponent } from './header/header.component'; // Adjust path as needed
// import { EventListComponent } from './event-list/event-list.component'; // Adjust path as needed

// @NgModule({
//     declarations: [
//         AppComponent,
//         FooterComponent,
//         HeroComponent,
//         HeaderComponent,
//         EventListComponent
//     ],
//     imports: [
//         BrowserModule,
//         RouterModule // Add RouterModule to imports
//     ],
//     providers: [],
//     bootstrap: [AppComponent]
// })
// export class AppModule { }

