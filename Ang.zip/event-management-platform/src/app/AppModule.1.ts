import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { EventListComponent } from "./event-list/event-list.component";
import { FooterComponent } from "./footer/footer.component";
import { HeaderComponent } from "./header/header.component";
import { HeroComponent } from "./hero/hero.component";


@NgModule({
    declarations: [
        AppComponent,
        // FooterComponent,
        // HeroComponent,
        // HeaderComponent,
        EventListComponent // Ensure this is declared here
    ],
    imports: [
    BrowserModule,
    RouterModule.forRoot([
        { path: '', component: EventListComponent },
        // Add additional routes as needed
    ]),
    HeroComponent,
    HeaderComponent,
    FooterComponent
],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}
