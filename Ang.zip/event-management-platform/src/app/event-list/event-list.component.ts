// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-event-list',
//   standalone: true,
//   imports: [],
//   templateUrl: './event-list.component.html',
//   styleUrl: './event-list.component.css'
// })
// export class EventListComponent {

// }


// import { Component, OnInit } from '@angular/core';
// import { EventService } from '../event.service';

// @Component({
//     selector: 'app-event-list',
//     templateUrl: './event-list.component.html',
//     styleUrls: ['./event-list.component.css']
// })
// export class EventListComponent implements OnInit {
//     events: any[] = []; // Replace 'any' with your event type

//     constructor(private eventService: EventService) {}

//     ngOnInit(): void {
//         this.events = this.eventService.getEvents(); // Fetch events from service
//     }
// }

// import { Component, OnInit } from '@angular/core';
// import { EventService } from '../event.service';

// @Component({
//   selector: 'app-event-list',
//   templateUrl: './event-list.component.html',
//   styleUrls: ['./event-list.component.css']
// })
// export class EventListComponent implements OnInit {
//   events: any[] = []; // Adjust based on your event structure

//   constructor(private eventService: EventService) {}

//   ngOnInit(): void {
//     this.events = this.eventService.getEvents(); // Fetch events from the service
//   }
// }

import { Component, OnInit } from '@angular/core';
import { EventService } from '../event.service'; // Adjust path as needed

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {
  events: any[] = []; // Replace 'any' with your specific event structure
  filteredEvents: any[] = []; // To hold filtered events
  searchTerm: string = ''; // Search term input

  constructor(private eventService: EventService) {}

  ngOnInit(): void {
    this.events = this.eventService.getEvents(); // Fetch events from the service
    this.filteredEvents = this.events; // Initialize filtered events
  }

  onSearchChange(searchValue: string): void {
    this.searchTerm = searchValue;
    this.filteredEvents = this.events.filter(event =>
      event.title.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}
