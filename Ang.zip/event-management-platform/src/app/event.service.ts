import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class EventService {
    private events = [
        {
            image: 'path-to-event1.jpg',
            title: 'Event 1',
            date: '2024-01-01',
            location: 'Location 1'
        },
        {
            image: 'path-to-event2.jpg',
            title: 'Event 2',
            date: '2024-01-02',
            location: 'Location 2'
        }
        // Add more events as needed
    ];

    getEvents() {
        return this.events;
    }
}
